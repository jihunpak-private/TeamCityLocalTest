from function import test


def test_answer():
    assert test.test2("alex") == "hello alex"
