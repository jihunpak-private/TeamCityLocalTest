from function import test


def test_answer():
    assert test.test(5, 8) == 13
